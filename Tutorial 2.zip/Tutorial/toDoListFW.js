function makeCookieFW() {

    "use strict";
    var toDoList = [];
    var count = 0;
    var cookieName = "ToDoListCookie";

    var fw = {};

    fw.makeList = function (id, name) {
        var ele = document.getElementById(id);

        var heading = document.createElement("h2");
        heading.innerHTML = name;
        ele.appendChild(heading);

        var input = document.createElement("input");
        input.setAttribute("id", "input" + name);
        input.type = "text";

        ele.appendChild(input);
        var button = document.createElement("button");
        button.innerHTML = "Add";
        button.style.width = "40px";
        ele.appendChild(button);

        var ul = document.createElement("ul");
        ele.appendChild(ul);

        //this event listener gets activated when "add" is clicked
        button.addEventListener("click", function () {
            if (document.getElementById("input" + name).value === "") {
                alert("This Field cannot be blank!");
            } else {
                var list = {};

                list.listTitle = name;
                list.ele = id;
                list.listText = document.getElementById("input" + name).value;
                list.listObjState = "uncrossed";
                addToList(list);
                addToCookie(list);
                input.value = "";
            }
        });

        //this event listener is activated when the user types in a task and presses enter
        input.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {

                if (document.getElementById("input" + name).value === "") {
                    alert("This Field cannot be blank!");
                } else {
                    var list = {};
                    list.listTitle = name;
                    list.ele = id;
                    list.listText = document.getElementById("input" + name).value;
                    list.listObjState = "uncrossed";
                    addToList(list);
                    addToCookie(list);
                    input.value = "";

                }
            }
        });

    };

    function addToList(listObj) {
        var ele = document.getElementById(listObj.ele);
        var task = document.createElement("li");
        task.style.listStyle = "none";
        ele.appendChild(task);
        var text = document.createTextNode(listObj.listText);
        task.appendChild(text);

        if (listObj.listObjState === "crossed") {
            task.style.backgroundColor = "grey";
            task.style.textDecoration = "line-through";
        }

        task.onclick = function () {
            if (listObj.listObjState === "uncrossed") {
                task.style.backgroundColor = "grey";
                task.style.textDecoration = "line-through";
                listObj.listObjState = "crossed";
                updateCookie(listObj);
            } else {
                task.style.backgroundColor = "initial";
                task.style.textDecoration = "none";
                listObj.listObjState = "uncrossed";
                updateCookie(listObj);
            }
        };

    };

    fw.clearCookie = function() {
        toDoList = [];
        deleteCookie(cookieName);
        location.reload();
        alert("All tasks from all lists will now be deleted");
    };

    function deleteCookie (cookie) {
        setCookie(cookie, "", -1);
    }

    fw.loadCookies = function() {
        var cookie = getCookie(cookieName);
        if (cookie !== "") {
            var parsedCookie = JSON.parse(cookie);
            console.log(cookie);
            console.log(parsedCookie);
            console.log(parsedCookie[0]);
            var i = 0;
            while (parsedCookie[i] !== undefined) {
                addToList(parsedCookie[i]);
                addToCookie(parsedCookie[i]);
                i++;
            }
        }
    };

    function getCookie (cookie) {
        var name = cookie + '=';
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        console.debug(document.cookie);
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) === 0) {
                console.log(c.substring(name.length, c.length));
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    function setCookie (cookie, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toGMTString();
        document.cookie = cookie + "=" + cvalue + ";" + expires + ";path=/";
        console.debug(document.cookie);
    }

    function addToCookie (listObj) {
        listObj.index = count;
        count++;
        toDoList[toDoList.length] = listObj;
        var cookieString = JSON.stringify(toDoList);
        setCookie(cookieName, cookieString, 1);
    }

    function updateCookie (listObj) {
        toDoList[listObj.index] = listObj;
        var cookieString = JSON.stringify(toDoList);
        setCookie(cookieName, cookieString, 1);
    }
    return fw;

}



